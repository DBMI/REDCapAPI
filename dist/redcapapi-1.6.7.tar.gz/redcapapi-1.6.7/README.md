[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
![Coverage Status](./.github/badges/coverage-badge.svg?dummy=8484744)
![Last Commit Date](https://img.shields.io/github/last-commit/dbmi/REDCapAPI)

[GitHub Pages site](https://dbmi.github.io/REDCapAPI/index.html)
# How to use `REDCapInterface` class to connect with REDCap API

## Obtaining a token
You will need to generate a token for yourself in the CAPMC project in REDCap. Click _API_ in the REDCap menu...:

![image info](./pictures/select_API.png)

...and then click _Request API token_:

![image info](./pictures/request_token.png)

Copy the file `config-example.key` to `F:\RedCap\secrets\config.key`. Put your token into `config.key` and save the file.

## Installing the `redcap_api` package
    pip install git+https://github.com/DBMI/REDCapAPI.git

This will allow you to import the `REDCapInterface` class within python:
`from redcap_api import REDCapInterface`
## Using the `REDCapInterface` Class
### CREATE
To create a new record, instantiate an object of the `REDCapInterface` class and call its `create` method, supplying a `dict` or `pandas.DataFrame` object:

    from redcap_api import REDCapInterface


    redcap_interface_object = REDCapInterface()
    new_data = {'study_id': '12345', 'name': "Patient's Name", 'mrn': 000000, ...}
    redcap_interface_object.create(new_data)

### RETRIEVE
To retrieve _all_ records, instantiate an object of the `REDCapInterface` class and call its `retrieve` method with no records specified:

    from redcap_api import REDCapInterface


    redcap_interface_object = REDCapInterface()
    df = redcap_interface_object.retrieve()

To retrieve selected records, specify a list of record numbers:

    df = redcap_interface_object.retrieve([20, 22])

Or to retrieve just one record by record number:

    df = redcap_interface_object.retrieve(42)
### UPDATE
Use the `create` method--if the `study_id` already exists, the existing record gets updated with whatever new fields you provide.

### DELETE
Use the `delete` method of the `REDCapInterface` class, specifying the record number (`study_id`) of the record to be deleted:

    from redcap_api import REDCapInterface


    redcap_interface_object = REDCapInterface()
    redcap_interface_object.delete(record_number_to_delete)
### HELPER FUNCTIONS
To determine whether a specific record is present in the database, use the `exists()` method:

    from redcap_api import REDCapInterface


    redcap_interface_object = REDCapInterface()

    if redcap_interface_object.exists(record_number): ...

To assist in creating a new record, look up the next available record number using the `next_record_number` method:

    from redcap_api import REDCapInterface


    redcap_interface_object = REDCapInterface()
    new_record_number = redcap_interface_object.next_record_number()

This `new_record_number` is guaranteed _not_ to exist. The highest record number that _does_ exist is found with the `last_record_number` method:

    from redcap_api import REDCapInterface


    redcap_interface_object = REDCapInterface()
    highest_record_number_in_use = redcap_interface_object.last_record_number()

To check what software version is used in the REDCapAPI, use the `version` method:

    from redcap_api import REDCapInterface


    redcap_interface_object = REDCapInterface()
    print(f"Version = {redcap_interface_object.version()}")
